# 골프 레프리 콘텐츠 생성기 — Claude Code 인수인계 가이드

> 작성일: 2026.03.20  
> 이어받는 곳: Claude Code (로컬 폴더 연결 완료)

---

## 1. 프로젝트 개요

KPGA 출신 레프리 채널을 위한 골프룰 쇼츠 콘텐츠 자동화 도구.  
골린이(골프 초보자) 타겟, 유튜브 쇼츠/릴스 1분 내외 대본 생성.

### 최종 목표
```
골프룰 소재 입력
    ↓
AI가 유형 자동 판단 (A/B/C)
    ↓
골린이 타겟 나레이션 대본 생성
    ↓
슬라이드 JSON 출력
    ↓
외주 편집자에게 전달
```

---

## 2. 폴더 구조

```
/
├── index.html          # 메인 페이지 (소재 선택 → 대본 생성)
├── scripts.html        # 2페이지 (대본 진행표 관리)
├── debug.html          # 디버그용 간단 페이지
├── src/
│   ├── main.js         # 진입점
│   ├── ui.js           # UI 이벤트 핸들러
│   ├── generator.js    # ⭐ 핵심: 대본 생성 로직
│   ├── mlr2026.js      # 2026 로컬룰 데이터
│   ├── topics.js       # 소재 목록 (TOPICS 배열)
│   ├── storage.js      # localStorage 히스토리
│   ├── scriptsPage.js  # 진행표 페이지 로직
│   └── dom.js          # DOM 유틸
```

---

## 3. 대본 생성 로직 (`generator.js`)

### 유형 판단 (`detectType`)

| 유형 | 트리거 키워드 | 설명 |
|------|-------------|------|
| C | 로컬룰, 대회룰, 레프리, MLR, 위원회 | 로컬룰/대회 전용 룰 |
| B | N가지, 총정리, 모음, 리스트, 자주 틀리는 | 리스트형 여러 룰 |
| A | 그 외 | 단일 룰 깊게 다루기 |

### 유형별 대본 구조

**유형 A (단일 룰):**
```
HOOK (창피/억울 상황)
→ 오해 (흔한 착각)
→ 긴장감 (벌타일까요?)
→ 판정 (룰 기준)
→ 실전 기준
→ 한 줄 요약
→ CTA
```

**유형 B (리스트형 일반 룰):**
```
HOOK (N가지 모르면 손해)
→ 항목 1~N (상황 → 룰 → 실전 팁)
→ 한 줄 요약
→ CTA
```

**유형 C (로컬룰):**
```
HOOK (골프장 안내판/TV 장면)
→ 배경 설명 (로컬룰이란?)
→ 항목 1~N (MLR_2026 데이터 활용)
→ 한 줄 요약
→ CTA
```

### CTA 고정 문구
```
레슨 받고 싶으세요?
KPGA 레프리가 검증한 티칭프로, 설명란 링크에서 확인하세요.
```
**CTA는 반드시 대본 전체에서 딱 1번, 마지막에만 출력.**

---

## 4. 현재까지 수정된 `generator.js` 주요 변경사항

Claude.ai 대화에서 수정 완료, 로컬에 반영 필요:

### 제거된 것
- `padToLength()` — filler 문장 반복 붙이는 함수 (CTA 무한반복 원인)
- `byId` 하드코딩 템플릿 — 특정 topic.id에만 작동하던 구조
- typeB 하드코딩 6개 항목 — 주제 무관하게 드롭/잠정구 반복

### 추가된 것
- `extractSituation()` — topic.hook, title에서 자연어 상황 자동 추출
- typeC 구어체 자동 변환 — `됩니다→돼요`, 괄호/영문 약어 제거
- `⚠️` 플레이스홀더 — 룰 내용 비어있으면 명확히 표시
- 슬라이드 나레이션 — 문단 단위로 자동 배분

> 수정된 `generator.js` 전체 파일은 이 가이드와 함께 전달된 파일 참조.

---

## 5. 남은 문제점 & 해야 할 것

### 🔴 Critical (지금 당장)

**[1] typeA/B — 룰 내용이 비어있음 → Claude API 연동 필요**

현재 단일 룰/리스트형 주제에서 판정 부분이 `⚠️ 플레이스홀더`로 출력됨.

**해결: Claude API 연동**

```javascript
// src/api.js 새로 만들기
export async function generateRuleContent({ topic, type }) {
  const systemPrompt = `
너는 골프룰 전문가다. 2026 개정룰 기준으로 정확한 판정을 골린이 눈높이 구어체로 설명한다.

규칙:
- 전문용어, 영문 약어, 괄호 설명 금지
- "됩니다" → "돼요", "합니다" → "해요" 구어체
- 따옴표로 시작/끝 금지
- 나레이션 텍스트만 출력 (번호, 표, 제목 금지)
- 벌타/숫자/핵심 기준 **Bold** 표시
- 3~5줄 이내로 간결하게
  `.trim();

  const userPrompt = type === 'A'
    ? `주제: ${topic.title}\n훅: ${topic.hook}\n룰 번호: ${topic.rules[0]?.ref}\n\n이 상황의 정확한 판정과 실전 기준을 골린이 눈높이로 설명해줘.`
    : `주제: ${topic.title}\n\n이 주제로 골린이가 알아야 할 핵심 룰 항목 ${topic.n || 5}가지를 각각 3줄 이내로 설명해줘.`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }]
    })
  });

  const data = await response.json();
  return data.content?.[0]?.text || '';
}
```

**[2] ANTHROPIC_API_KEY 환경변수 설정**

```bash
# .env 파일 생성
VITE_ANTHROPIC_API_KEY=your_key_here
```

```javascript
// 사용 시
const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;
```

---

### 🟡 Important (다음 우선순위)

**[3] 2026 룰 문서 컨텍스트 주입**

현재 `mlr2026.js`에 로컬룰 데이터는 있는데,  
일반 본룰(Rule 9, 16, 17, 18 등) 개정 내용이 없음.

```
방법 1 (추천): R&A 공식 URL fetch → Claude API system prompt에 포함
방법 2: 룰 텍스트 파일 → src/rules2026.js로 저장 → system prompt에 주입
방법 3: NotebookLM → API 연동 불가, 텍스트로 변환 후 파일로 저장 필요
```

**[4] 확정된 대본 시스템 프롬프트**

```
유형 A: 단일 룰 → HOOK(창피/억울) → 오해 → 긴장감 → 판정 → 기준 → 요약 → CTA
유형 B: 리스트 → HOOK → N개 항목(상황+룰+팁) → 요약 → CTA
유형 C: 로컬룰 → HOOK(신기함/몰랐던 사실) → 배경 → 항목 → 요약 → CTA

공통 규칙:
- 따옴표로 시작/끝 금지
- 나레이션 텍스트만 출력 (번호, 표, 제목 금지)
- 문단 사이 한 줄 공백
- 벌타/숫자/핵심 기준 Bold 표시
- 전문용어/영문약어/괄호 금지
- CTA 딱 1번, 마지막에만
- 로컬룰은 창피/억울 훅 금지 → 신기함/몰랐던 사실 각도
```

---

### 🟢 Nice to have (여유 있을 때)

**[5] Gemini API 썸네일 생성 연동**

```javascript
// Nano Banana (gemini-2.5-flash-image) 사용
// API 키: Google AI Studio에서 발급 (GEMINI_API_KEY)
// 무료 티어: 하루 500개
// 썸네일 텍스트는 Nano Banana Pro가 정확도 높음
```

**[6] 골프룰 스킬 파이프라인**

Claude.ai에서 만든 스킬 파일들:
- `golf-content-pipeline.skill` — 소재/대본/썸네일 자동 생성
- `golf-script-polish.skill` — "골프대본" 키워드로 트리거, 초안 다듬기

---

## 6. 사업 컨텍스트 (개발 방향 이해용)

```
채널 목표: 골린이 → 티칭프로 매칭 플랫폼
수익 모델: 티칭프로 월정액 리스팅 (5~10만원/월)
타겟: 골린이 (라운딩 1~10회)
채널 현황: 구독자 40명 → 목표 500명 (2달 내)
레프리분: KPGA 출신, 프로 지인 100명+, 컨펌 대기 중
CTA 최종 목적: 설명란 티칭프로 리스팅 웹사이트 링크
런칭 목표: 2026년 4월 중순
```

---

## 7. 실행 방법

```bash
# 패키지 설치
npm install

# 로컬 서버 실행
npm run dev

# 빌드
npm run build
```

---

## 8. 주요 파일 수정 시 주의사항

| 파일 | 주의사항 |
|------|---------|
| `generator.js` | CTA 중복 방지 로직 건드리지 말 것 |
| `mlr2026.js` | R&A 원문 확인 후 수정할 것 |
| `topics.js` | id 중복 확인 필수 |
| `scriptsPage.js` | localStorage 키 변경 시 기존 데이터 초기화됨 |

---

## 9. Claude Code 세션 시작 시 순서

```
1. npm run dev 실행 확인
2. 수정된 generator.js 로컬에 덮어쓰기
3. .env 파일에 ANTHROPIC_API_KEY 추가
4. src/api.js 생성 (Claude API 연동)
5. generator.js의 ⚠️ 플레이스홀더 → api.js 호출로 교체
6. 각 유형 (A/B/C) 테스트
7. 이상 없으면 Gemini 썸네일 연동
```

---

*작성: Claude.ai 대화 기반 | 2026.03.20*
