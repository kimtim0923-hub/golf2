import { MLR_2026, PREFERRED_LIES } from './mlr2026.js';

export function buildManualTopic(ideaText) {
  const clean = (ideaText || '').trim();
  return {
    id: `t_manual_${Date.now()}`,
    type: 'info',
    category: 'Manual idea',
    title: clean ? clean : '내 아이디어',
    hook: clean || '내가 겪은 상황을 룰 기준으로 정리합니다.',
    target: '라운드 10회 이상 백돌이',
    rules: [{ ref: 'Rule (TBD)', url: 'https://www.randa.org/en/rog/the-rules-of-golf' }],
    notes: '사용자 아이디어 기반. 업로드 전 해당 상황의 정확한 룰을 최종 확인하세요.'
  };
}

function pickNByText(textAll, fallback = 5) {
  const m = textAll.match(/(\d+)\s*가지/);
  const nRaw = m ? parseInt(m[1], 10) : fallback;
  return Math.max(3, Math.min(6, Number.isFinite(nRaw) ? nRaw : fallback));
}

function ensureNoQuotesAtEdges(text) {
  let t = String(text || '').trim();
  if (t.startsWith('"') && t.endsWith('"')) t = t.slice(1, -1).trim();
  return t;
}

function boldImportant(text) {
  return String(text)
    .replace(/(\d+\s*벌타)/g, '**$1**')
    .replace(/(무벌타)/g, '**$1**')
    .replace(/(\d+\s*클럽(?:\s*길이)?)/g, '**$1**')
    .replace(/(3\s*분|3분)/g, '**$1**')
    .replace(/(스코어카드\s*길이|스코어카드)/g, '**$1**')
    .replace(/(무릎\s*높이)/g, '**$1**');
}

function detectType(textAll) {
  // 로컬룰/대회룰 먼저 체크
  if (/로컬\s*룰|대회\s*룰|레프리|MLR|위원회|모델\s*로컬/i.test(textAll)) return 'C';
  // 리스트형
  if (/(\d+\s*가지)|총\s*정리|전체\s*정리|모음|리스트|TOP\s*\d+|자주\s*틀리|꼭\s*알아야|라운딩\s*전\s*꼭/i.test(textAll)) return 'B';
  return 'A';
}

// 주제에서 핵심 상황을 자연어로 추출
function extractSituation(topic) {
  const title = topic.title || '';
  const hook = topic.hook || '';

  // hook이 있으면 우선 사용
  if (hook && hook.length > 5) return hook;

  // title에서 물음표 앞 상황 추출
  const q = title.split('?')[0];
  if (q && q.length > 4) return q.trim();

  return title;
}

const paragraphGap = '\n\n';

// ─── 유형 A: 단일 룰 ───────────────────────────────────────────
function typeA(topic, userNotes) {
  const situation = extractSituation(topic);
  const title = topic.title || '';

  // 훅: 골린이 일상 창피/억울 상황
  // 로컬룰이 아닌 일반 룰이므로 현장감 있는 훅 사용
  const hook = `라운드에서 ${situation} 경험해본 적 있으시죠?\n그 순간 어떻게 해야 할지 몰라서 당황했던 분들, 생각보다 많아요.`;

  // 오해: 흔한 착각
  const misconception = `보통은 이렇게 생각하시잖아요.\n"대충 알고 있으니까 괜찮겠지", "동반자 하는 대로 따라 하면 되겠지." 라고요.`;

  // 긴장감
  const tension = `그런데 여기서 문제가 생깁니다.\n이 상황에서 잘못 처리하면 벌타가 붙을 수 있어요. 벌타일까요? 아닐까요?`;

  // 판정: 주제별 룰 번호 활용
  const ruleRef = topic.rules && topic.rules[0] ? topic.rules[0].ref : '골프 룰';
  const decision = `결론부터 말하면, ${ruleRef} 기준으로 정해진 절차가 있습니다.\n${topic.notes ? topic.notes.split('.')[0] + '.' : '공식 룰에 따라 기준점과 절차를 지키면 됩니다.'}\n\n⚠️ 이 부분은 실제 룰 내용으로 교체 필요: [${title}의 핵심 판정 내용]`;

  // 기준
  const standard = `실전에서 기억할 건 하나예요.\n감으로 처리하지 말고, 눈으로 확인할 수 있는 기준으로 처리하세요.\n무릎 높이, 클럽 길이처럼 명확한 기준이 있으면 분쟁이 사라집니다.`;

  // 요약
  const summary = `한 줄 정리.\n${title.length > 20 ? '기준점과 절차' : title}로 끝낸다.`;

  const cta = `레슨 받고 싶으세요?\nKPGA 레프리가 검증한 티칭프로, 설명란 링크에서 확인하세요.`;

  return [hook, misconception, tension, decision, standard, summary, cta].join(paragraphGap);
}

// ─── 유형 B: 리스트형 (일반 룰) ───────────────────────────────
function typeB(topic, userNotes, textAll) {
  const n = pickNByText(textAll, 5);
  const title = topic.title || '골프 룰';

  const open = `이거 모르면 오늘 라운딩에서 바로 손해 봅니다.\n${title} ${n}가지, 지금 1분에 정리할게요.`;

  // 주제 기반 항목 생성 — 하드코딩 제거, 주제에서 유추
  // 실제 룰 내용은 ⚠️ 표시로 교체 필요 안내
  const connectors = ['첫 번째는', '두 번째는', '세 번째는', '네 번째는', '다섯 번째는', '여섯 번째는'];

  const placeholderItems = Array.from({ length: n }, (_, i) => (
    `${connectors[i]} ⚠️ [${title} - ${i + 1}번째 핵심 내용을 여기에]\n실전에서는 이렇게 하세요. ⚠️ [구체적인 처리 방법]`
  ));

  const body = placeholderItems.join(paragraphGap);

  const summary = `이 ${n}가지만 알면 오늘 라운딩 준비 끝입니다.`;

  const cta = `레슨 받고 싶으세요?\nKPGA 레프리가 검증한 티칭프로, 설명란 링크에서 확인하세요.`;

  return [open, body, summary, cta].join(paragraphGap);
}

// ─── 유형 C: 리스트형 (로컬룰/대회룰) ────────────────────────
function typeC(topic, userNotes, textAll) {
  const n = pickNByText(textAll, 6);
  const pgaVariant = /PGA|프리퍼드\s*라이|preferred\s*lies/i.test(textAll);

  const open = `골프장 안내판에 적혀 있는 규칙, 솔직히 잘 안 읽게 되죠?\n그런데 그게 로컬룰이고, 2026년에 6가지가 업데이트됐습니다.`;

  const background = `핵심은 이거예요.\n기본 룰 위에 골프장이나 대회가 선택해서 추가로 쓰는 규칙이 있어요.\n그래서 같은 상황인데 골프장마다 처리가 달라 보일 수 있습니다.`;

  const useItems = pgaVariant
    ? [MLR_2026[0], MLR_2026[1], MLR_2026[2], MLR_2026[3], MLR_2026[5], PREFERRED_LIES]
    : MLR_2026;

  const items = useItems.slice(0, n);
  const connectors = ['첫 번째는', '두 번째는', '세 번째는', '네 번째는', '다섯 번째는', '여섯 번째는'];

  // 문어체 → 구어체로 변환, 괄호/약어 제거
  const body = items.map((it, i) => {
    // name 간소화: 괄호 제거
    const cleanName = it.name.replace(/\(.*?\)/g, '').trim();

    // desc → 구어체 변환
    const cleanDesc = it.desc
      .replace(/되었습니다/g, '됐어요')
      .replace(/있습니다/g, '있어요')
      .replace(/됩니다/g, '돼요')
      .replace(/합니다/g, '해요')
      .replace(/[가-힣]+\([A-Za-z\s]+\)/g, (m) => m.split('(')[0]) // 영문 약어 제거
      .replace(/\(.*?\)/g, '') // 나머지 괄호 제거
      .trim();

    // tip → 구어체
    const cleanTip = it.tip
      .replace(/됩니다/g, '돼요')
      .replace(/있습니다/g, '있어요')
      .replace(/합니다/g, '해요')
      .trim();

    return `${connectors[i]} ${cleanName}입니다.\n${cleanDesc}\n실전 팁: ${cleanTip}`;
  }).join(paragraphGap);

  const summary = `한 줄 정리.\n로컬룰은 위원회가 채택한 것만 적용되니까, 라운딩 전 안내판 확인이 핵심입니다.`;

  const cta = `레슨 받고 싶으세요?\nKPGA 레프리가 검증한 티칭프로, 설명란 링크에서 확인하세요.`;

  return [open, background, body, summary, cta].join(paragraphGap);
}

// ─── 메인 나레이션 생성 ────────────────────────────────────────
export function makeNarration({ topic, userNotes }) {
  const notes = String(userNotes || '').trim();
  const textAll = `${topic.title} ${topic.hook} ${notes}`;

  const type = detectType(textAll);

  let draft;
  if (type === 'C') {
    draft = typeC(topic, notes, textAll);
  } else if (type === 'B') {
    draft = typeB(topic, notes, textAll);
  } else {
    draft = typeA(topic, notes);
  }

  draft = ensureNoQuotesAtEdges(draft);
  draft = boldImportant(draft);

  // 번호 패턴 제거
  draft = draft.replace(/^\s*\d+[.)]\s*/gm, '');

  // CTA 중복 제거: 마지막 1개만 남김
  const cta = `레슨 받고 싶으세요?\nKPGA 레프리가 검증한 티칭프로, 설명란 링크에서 확인하세요.`;
  const parts = draft.split(cta);
  if (parts.length > 2) {
    draft = parts.slice(0, -1).join('').trim() + paragraphGap + cta;
  }

  return draft.trim();
}

// ─── 슬라이드 JSON 생성 ───────────────────────────────────────
export function buildSlideScript({ topic, userNotes }) {
  const fullNarrationDraft = makeNarration({ topic, userNotes });
  const sourceLines = (topic.rules || []).map(r => `${r.ref} (${r.url})`).join(', ');

  const base = {
    videoTitle: topic.title,
    format: '슬라이드형(10초/장) · 총 12장 · 총 120초 내',
    voice: '한국어 내레이션',
    audience: '라운드 10회 이상 백돌이',
    compliance: {
      policy: 'Rules of Golf + 2026 MLR 업데이트 요약 기반',
      sources: topic.rules,
      userNotes: (userNotes || '').trim(),
    },
  };

  const slides = [];

  slides.push({
    slideNo: 1,
    durationSec: 10,
    visual: '타이틀 카드(큰 글씨) + 심플 아이콘(깃발/볼/규칙서).',
    onScreenText: `오늘의 주제: ${topic.title}`,
    narration: '오늘은 골프 규칙을 1분으로 정리합니다.'
  });

  slides.push({
    slideNo: 2,
    durationSec: 10,
    visual: '상황 카드(만화 말풍선/미니 시나리오).',
    onScreenText: '상황: 라운드에서 실제로 자주 생기는 순간',
    narration: topic.hook
  });

  // 나레이션을 문단 단위로 슬라이드에 배분
  const narParagraphs = fullNarrationDraft.split(/\n\n+/).filter(Boolean);
  const slideCount = Math.min(narParagraphs.length, 9); // 슬라이드 3~11번에 배분

  for (let i = 0; i < 9; i++) {
    const para = narParagraphs[i + 1] || ''; // 첫 문단은 훅으로 사용했으므로 +1
    slides.push({
      slideNo: i + 3,
      durationSec: 10,
      visual: i === slideCount - 1 ? '요약 카드(핵심 1줄 크게).' : '보조 이미지(아이콘/도식/텍스트).',
      onScreenText: para.replace(/\*\*/g, '').split('\n')[0].slice(0, 30),
      narration: para.replace(/\*\*/g, '').slice(0, 120)
    });
  }

  slides.push({
    slideNo: 12,
    durationSec: 10,
    visual: '출처 카드(텍스트로만 표기).',
    onScreenText: 'Source: Rules of Golf (USGA / R&A)',
    narration: '공식 링크는 영상 설명란에서 확인하세요.',
    sources: sourceLines,
  });

  return {
    ...base,
    slides,
    fullNarrationDraft,
    fullNarrationCharCount: fullNarrationDraft.length,
    warningNote: '⚠️ 표시된 부분은 실제 룰 내용으로 교체 후 업로드하세요.'
  };
}
